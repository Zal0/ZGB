#ifndef STATE_MENU_H
#define STATE_MENU_H

#include "main.h"

DECLARE_STATE(STATE_MENU);

#endif