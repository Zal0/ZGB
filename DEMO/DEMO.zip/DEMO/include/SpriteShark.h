#ifndef SPRITE_SHARK_H
#define SPRITE_SHARK_H

#include "main.h"

DECLARE_SPRITE(SPRITE_SHARK);

#endif